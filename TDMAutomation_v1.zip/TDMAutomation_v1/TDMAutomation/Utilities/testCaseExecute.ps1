﻿# Path to the ReadyAPI testrunner.bat
$testrunnerPath = "C:\Program Files\SmartBear\ReadyAPI-3.51.0\bin\testrunner.bat"

# Path to your full ReadyAPI project (the folder that contains settings.xml, etc.)
$projectPath = "C:\Users\AIragavarapu\Code\GIT\Sonata_Automation_Framework\Sonata.Tests.Hybrid\SOAPProjects\SONATA_Combo"

# Test suite and test case names
$suiteName = "SONATA_Automation_TDD"  # or whatever suite contains TestCaseExecute
$caseName = "TestCaseExecute"

# Build and run the command
$command = "& `"$testrunnerPath`" -s`"$suiteName`" -c`"$caseName`" `"$projectPath`""
Invoke-Expression $command
