﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using System.Linq;
using System.Diagnostics;
using System.Collections.Generic; // Make sure this is present


namespace TDMAutomation
{
    public partial class Form1 : Form
    {
        private string configPath;
        private string currentCsvPath; // This will be set when the user browses for a scenario file
        private string logFilePath;    // This will now be consistently defined


        public Form1()
        {
            InitializeComponent();
            this.dataGridView1.KeyDown += new KeyEventHandler(this.dataGridView1_KeyDown);
            logFilePath = "C:\\Users\\AIragavarapu\\Desktop\\util\\ExecutionLog.csv";
            if (!File.Exists(logFilePath))
            {
                try
                {
                    // Write the header if the file is new.
                    // This makes sure the log is always well-formed even if cleared or new.
                    File.WriteAllText(logFilePath, "Timestamp,TestCaseID,Keyword,Execution_Flag\n");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error creating log file header: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            tdmRunTextBox.Enabled = false; // Disable editin
            carryOnTestCaseComboBox.SelectedIndex = 1; // Default to FALSE
            carryOnTestCaseComboBox.Enabled = false; // Disable editing

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV files (*.csv)|*.csv";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txtLocation.Text = openFileDialog.FileName;
                LoadCsv(openFileDialog.FileName);
            }
        }

        private void LoadCsv(string filePath)
        {
            currentCsvPath = filePath;
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(filePath))
            {
                string[] headers = sr.ReadLine()?.Split(',');
                if (headers == null) return;

                int[] columnsToKeep = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
                // int[] columnsToKeep = { 0, 2, 4, 5, 6, 7, 8, 9, 12 }; // Commented out original

                // Ensure all indices are within bounds
                columnsToKeep = columnsToKeep.Where(i => i < headers.Length).ToArray();

                foreach (int index in columnsToKeep)
                {
                    dt.Columns.Add(headers[index]);
                }

                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine()?.Split(',');
                    if (rows == null || rows.Length < headers.Length) continue;

                    DataRow dr = dt.NewRow();
                    foreach (int index in columnsToKeep)
                    {
                        if (index < rows.Length)
                            dr[headers[index]] = rows[index];
                        else
                            dr[headers[index]] = ""; // Fill with empty string if missing
                    }
                    dt.Rows.Add(dr);
                }
            }
            dataGridView1.DataSource = dt;
        }

        // This is your "Run" button
        private void btnSaveCsv_Click(object sender, EventArgs e)
        {
            if (dataGridView1.DataSource is DataTable dt && !string.IsNullOrEmpty(currentCsvPath))
            {
                // 1. Save the current CSV first to reflect all 'Y's (including those from Ctrl+D)
                SaveDataTableToCsv(dt, currentCsvPath);

                // 2. Identify potential reruns and first-time runs
                var potentialReruns = new List<DataRow>();
                var firstTimeRuns = new List<DataRow>();

                // Pre-check for required columns
                if (!dt.Columns.Contains("Execution_Flag") || !dt.Columns.Contains("TestCaseID") || !dt.Columns.Contains("Keyword"))
                {
                    MessageBox.Show("The loaded CSV must contain 'Execution_Flag', 'TestCaseID', and 'Keyword' columns.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                foreach (DataRow row in dt.Rows)
                {
                    string flag = row["Execution_Flag"].ToString().Trim().ToUpper();

                    if (flag == "Y")
                    {
                        string testCaseId = row["TestCaseID"].ToString();
                        string keyword = row["Keyword"].ToString();

                        if (WasStepPreviouslyRun(testCaseId, keyword, logFilePath))
                        {
                            potentialReruns.Add(row); // This step needs rerun consideration
                        }
                        else
                        {
                            firstTimeRuns.Add(row); // This is a genuine first-time run (for 'Y' steps)
                        }
                    }
                }

                // 3. Handle multiple reruns with the checkbox dialog (if any)
                if (potentialReruns.Any())
                {
                    if (potentialReruns.Count == 1)
                    {
                        DialogResult userDecision = MessageBox.Show(
                            $"Step '{potentialReruns[0]["TestCaseID"]}' with keyword '{potentialReruns[0]["Keyword"]}' was already run. Do you want to rerun it?",
                            "Confirm Rerun",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (userDecision == DialogResult.Yes)
                        {
                            int currentRerunCount = GetLastRerunCount(potentialReruns[0]["TestCaseID"].ToString(), potentialReruns[0]["Keyword"].ToString(), logFilePath);
                            potentialReruns[0]["Execution_Flag"] = $"Reran - {currentRerunCount + 1}";
                        }
                        else
                        {
                            potentialReruns[0]["Execution_Flag"] = "C"; // Mark as skipped
                        }
                    }
                    else // Multiple potential reruns
                    {
                        DataTable rerunReviewDt = new DataTable();
                        rerunReviewDt.Columns.Add("TestCaseID", typeof(string));
                        rerunReviewDt.Columns.Add("Keyword", typeof(string));

                        foreach (DataRow row in potentialReruns)
                        {
                            DataRow newRow = rerunReviewDt.NewRow();
                            newRow["TestCaseID"] = row["TestCaseID"];
                            newRow["Keyword"] = row["Keyword"];
                            rerunReviewDt.Rows.Add(newRow);
                        }

                        using (FormRerunSelection rerunForm = new FormRerunSelection(rerunReviewDt))
                        {
                            rerunForm.StartPosition = FormStartPosition.CenterParent;
                            DialogResult formResult = rerunForm.ShowDialog(this);

                            if (formResult == DialogResult.OK)
                            {
                                DataTable reviewedDt = rerunForm.RerunStepsDataTable;

                                foreach (DataRow reviewedRow in reviewedDt.Rows)
                                {
                                    string reviewedTestCaseId = reviewedRow["TestCaseID"].ToString();
                                    string reviewedKeyword = reviewedRow["Keyword"].ToString();
                                    bool rerunSelected = (bool)reviewedRow["RerunSelected"];

                                    DataRow originalRow = potentialReruns.FirstOrDefault(r =>
                                        r["TestCaseID"].ToString().Equals(reviewedTestCaseId, StringComparison.OrdinalIgnoreCase) &&
                                        r["Keyword"].ToString().Equals(reviewedKeyword, StringComparison.OrdinalIgnoreCase));

                                    if (originalRow != null)
                                    {
                                        if (rerunSelected)
                                        {
                                            int currentRerunCount = GetLastRerunCount(reviewedTestCaseId, reviewedKeyword, logFilePath);
                                            originalRow["Execution_Flag"] = $"Reran - {currentRerunCount + 1}";
                                        }
                                        else
                                        {
                                            originalRow["Execution_Flag"] = "C"; // Mark as completed (skipped)
                                        }
                                    }
                                }
                            }
                            else if (formResult == DialogResult.Cancel)
                            {
                                MessageBox.Show("Rerun operation cancelled by user.", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return; // Stop execution if cancelled
                            }
                        }
                    }
                }

                // 4. Gather all rows that are actually going to be executed after all decisions
                var rowsToExecuteAndLog = dt.AsEnumerable()
                                             .Where(row =>
                                                 row["Execution_Flag"].ToString().Trim().ToUpper() == "Y" || // Still 'Y' for first-time runs
                                                 row["Execution_Flag"].ToString().Trim().StartsWith("RERAN - ", StringComparison.OrdinalIgnoreCase))
                                             .ToList();


                // 5. Iterate through each row to execute the PowerShell script individually
                if (rowsToExecuteAndLog.Any())
                {
                    string scriptPath = @"\\royallondongroup.com\users\group\AIragavarapu\Documents\testScript.ps1";

                    using (StreamWriter logWriter = new StreamWriter(logFilePath, true)) // 'true' to append
                    {
                        foreach (var row in rowsToExecuteAndLog)
                        {
                            string testCaseId = row["TestCaseID"].ToString();
                            string keyword = row["Keyword"].ToString();
                            string currentFlag = row["Execution_Flag"].ToString(); // Get the flag before potential update

                            // Removed: MessageBox.Show($"Executing script for: TestCaseID='{testCaseId}', Keyword='{keyword}'", "Executing Step", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            var psi = new ProcessStartInfo()
                            {
                                FileName = "powershell.exe",
                                Arguments = $"-ExecutionPolicy Bypass -File \"{scriptPath}\"",
                                UseShellExecute = false,
                                RedirectStandardOutput = true,
                                RedirectStandardError = true,
                                CreateNoWindow = true
                            };

                            using (var process = new Process())
                            {
                                process.StartInfo = psi;
                                try
                                {
                                    process.Start();
                                    // You can optionally read output/error here if you want to log it internally without showing to user
                                    string output = process.StandardOutput.ReadToEnd();
                                    string error = process.StandardError.ReadToEnd();

                                    process.WaitForExit(); // Wait for the 5-second script to finish

                                    if (process.ExitCode != 0)
                                    {
                                        MessageBox.Show($"PowerShell script failed for {testCaseId} - {keyword}:\n{error}", "Script Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        // Decide if you want to continue or stop on error
                                        // If you want to stop, uncomment 'return;'
                                        // return; 
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show($"Error starting PowerShell process for {testCaseId} - {keyword}: {ex.Message}", "Process Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    // If you want to stop, uncomment 'return;'
                                    // return;
                                }
                            }

                            // Update Execution_Flag to 'C' for 'Y' flags *after* script execution for first-time runs
                            // Reran flags already have their proper value set from the rerun dialog
                            if (currentFlag.Trim().ToUpper() == "Y")
                            {
                                row["Execution_Flag"] = "C";
                            }

                            // Log executed step immediately after its script run
                            string statusForLog = row["Execution_Flag"].ToString(); // Use the potentially updated flag
                            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                            logWriter.WriteLine($"{timestamp},{testCaseId},{keyword},{statusForLog}");
                        }
                    } // End using (StreamWriter logWriter)
                }

                // 6. Save updated CSV one final time to persist all 'C' or 'Reran - X' flags
                SaveDataTableToCsv(dt, currentCsvPath);

                MessageBox.Show("Scenario processing complete. Each marked step triggered the script.", "Process Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No scenario data loaded or file path is missing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ... (rest of Form1.cs methods like WasStepPreviouslyRun, GetLastRerunCount, SaveDataTableToCsv, etc.) ...

        private bool WasStepPreviouslyRun(string testCaseId, string keyword, string logPath)
        {
            if (!File.Exists(logPath))
            {
                return false; // Log file doesn't exist, so nothing was run yet
            }

            try
            {
                // Read all lines, skip header, and check if any entry matches the TestCaseID and Keyword
                return File.ReadLines(logPath)
                           .Skip(1) // Skip header line
                           .Any(line =>
                           {
                               string[] parts = line.Split(',');
                               // Assuming log format: Timestamp,TestCaseID,Keyword,Execution_Flag
                               // Make sure indices match your log format.
                               // parts[0] = Timestamp, parts[1] = TestCaseID, parts[2] = Keyword, parts[3] = Execution_Flag
                               return parts.Length > 2 &&
                                            parts[1].Trim().Equals(testCaseId, StringComparison.OrdinalIgnoreCase) &&
                                            parts[2].Trim().Equals(keyword, StringComparison.OrdinalIgnoreCase);
                           });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error checking previous run status from log: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Helper method to get the last rerun count for a specific TestCaseID and Keyword
        private int GetLastRerunCount(string testCaseId, string keyword, string logPath)
        {
            if (!File.Exists(logPath))
            {
                return 0; // No log, so no previous rerun count
            }

            int maxRerun = 0; // Will hold the highest rerun number found
            try
            {
                // Read all lines and iterate backwards to find the latest rerun count
                string[] logLines = File.ReadAllLines(logPath);

                // Iterate from last line, skipping the header (index 0)
                for (int i = logLines.Length - 1; i >= 1; i--)
                {
                    string line = logLines[i];
                    string[] parts = line.Split(','); // Assuming comma is the delimiter
                    if (parts.Length > 3) // Ensure enough columns (Timestamp,TestCaseID,Keyword,Execution_Flag)
                    {
                        string loggedTestCaseId = parts[1].Trim();
                        string loggedKeyword = parts[2].Trim();
                        string loggedFlag = parts[3].Trim();

                        // Check if it's the same TestCaseID and Keyword we're interested in
                        if (loggedTestCaseId.Equals(testCaseId, StringComparison.OrdinalIgnoreCase) &&
                            loggedKeyword.Equals(keyword, StringComparison.OrdinalIgnoreCase))
                        {
                            // Check if it's a "Reran - X" entry
                            if (loggedFlag.StartsWith("Reran - ") && int.TryParse(loggedFlag.Replace("Reran - ", ""), out int currentRerun))
                            {
                                // We found the most recent rerun count for this specific TestCaseID and Keyword
                                return currentRerun; // Return immediately as we found the latest
                            }
                            else if (loggedFlag.Equals("First Run", StringComparison.OrdinalIgnoreCase) || loggedFlag.Equals("C", StringComparison.OrdinalIgnoreCase))
                            {
                                // If we encounter a "First Run" or "C" for this TestCaseID/Keyword,
                                // it means any subsequent run will be "Reran - 1"
                                return 0; // No previous rerun count for this specific item
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading rerun count from log: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return 0; // Default to 0 if no matching rerun entry found
        }

        // Your existing SaveDataTableToCsv method
        private void SaveDataTableToCsv(DataTable dt, string filePath)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(filePath, false)) // 'false' to overwrite
                {
                    // Write header
                    IEnumerable<string> header = dt.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
                    sw.WriteLine(string.Join(",", header));

                    // Write rows
                    foreach (DataRow row in dt.Rows)
                    {
                        IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                        sw.WriteLine(string.Join(",", fields));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving CSV: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDialog = new FolderBrowserDialog();
            if (folderDialog.ShowDialog() == DialogResult.OK)
            {
                configPath = Path.Combine(folderDialog.SelectedPath, @"Data\Config\");
                pathTextBox.Text = configPath;
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(configPath)) return;

            string selectedEnvironment = envComboBox.SelectedItem?.ToString();
            string dbPassword = dbPasswordTextBox.Text;

            if (string.IsNullOrEmpty(selectedEnvironment) || string.IsNullOrEmpty(dbPassword))
            {
                MessageBox.Show("Please select an environment and enter a DB password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string configFile = Path.Combine(configPath, "Config.csv");
            string envManagerFile = Path.Combine(configPath, "Environment_Manager.csv");

            var configData = File.ReadAllLines(configFile).Select(line => line.Split(',')).ToList();

            // Updating Config.csv
            for (int i = 0; i < configData.Count; i++)
            {
                if (configData[i][0] == "Environment") configData[i][1] = selectedEnvironment;
                if (configData[i][0] == "UserName") configData[i][1] = userNameTextBox.Text;
                if (configData[i][0] == "Password") configData[i][1] = passwordTextBox.Text;
                if (configData[i][0] == "DBPassword") configData[i][1] = dbPassword; // Updating DBPassword
                if (configData[i][0] == "TDMRun") configData[i][1] = "TRUE"; // Always TRUE
                if (configData[i][0] == "CarryOnTestCase") configData[i][1] = "FALSE"; // Always FALSE
                if (configData[i][0] == "Retries") configData[i][1] = "6"; // Always 6
            }
            File.WriteAllLines(configFile, configData.Select(line => string.Join(",", line)));

            // Updating Environment_Manager.csv
            var envManagerData = File.ReadAllLines(envManagerFile).Select(line => line.Split(',')).ToList();
            int envColumnIndex = -1;

            // Find the column index for the selected environment
            string[] headers = envManagerData[0]; // First row contains headers
            for (int i = 0; i < headers.Length; i++)
            {
                if (headers[i] == selectedEnvironment)
                {
                    envColumnIndex = i;
                    break;
                }
            }

            if (envColumnIndex > -1)
            {
                for (int i = 1; i < envManagerData.Count; i++) // Start from row after headers
                {
                    if (envManagerData[i][0] == "sondbUserpwd") // Matching key
                    {
                        envManagerData[i][envColumnIndex] = dbPassword; // Update password in correct environment column
                        break;
                    }
                }

                File.WriteAllLines(envManagerFile, envManagerData.Select(line => string.Join(",", line)));
                MessageBox.Show("Config and Environment Manager files updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Environment not found in Environment_Manager.csv!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (envComboBox.Items.Count > 0) // Ensure dropdown has items
            {
                envComboBox.SelectedIndex = 0; // Set default selection
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            // Check if Ctrl + D is pressed and there is a currently selected cell
            if (e.Control && e.KeyCode == Keys.D && dataGridView1.CurrentCell != null)
            {
                // Ensure the DataGridView is not read-only
                if (dataGridView1.ReadOnly)
                {
                    MessageBox.Show("The DataGridView is read-only. Cannot fill down.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Handled = true; // Prevent default action
                    e.SuppressKeyPress = true;
                    return;
                }

                // Get the value from the current cell (the one you typed 'Y' in)
                object valueToFill = dataGridView1.CurrentCell.Value;
                int targetColumnIndex = dataGridView1.CurrentCell.ColumnIndex;

                // Ensure the target column is editable
                if (dataGridView1.Columns[targetColumnIndex].ReadOnly)
                {
                    MessageBox.Show("This column is read-only. Cannot fill down.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                    return;
                }

                // Get all selected cells in the target column, ordered by row
                // This mimics Excel's behavior where you select a range and it fills from the top
                var selectedCellsInTargetColumn = dataGridView1.SelectedCells
                                                         .Cast<DataGridViewCell>()
                                                         .Where(c => c.ColumnIndex == targetColumnIndex)
                                                         .OrderBy(c => c.RowIndex)
                                                         .ToList();

                if (selectedCellsInTargetColumn.Any())
                {
                    // The value to fill down from should be the value of the topmost selected cell in that column
                    // This ensures that if you select multiple cells, the first one's value is propagated.
                    valueToFill = selectedCellsInTargetColumn.First().Value;

                    // Apply the value to all selected cells in the target column
                    foreach (DataGridViewCell cell in selectedCellsInTargetColumn)
                    {
                        // Only update if the cell's value is different to avoid unnecessary writes
                        if (!object.Equals(cell.Value, valueToFill))
                        {
                            cell.Value = valueToFill;
                        }
                    }

                    // End the current edit operation to commit changes to the underlying data source
                    dataGridView1.EndEdit();

                    // Optional: Invalidate to ensure immediate visual update
                    dataGridView1.Invalidate();
                }

                // Prevent the default Ctrl+D behavior (e.g., opening font dialog in some apps)
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void btnClearHistory_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to clear the Execution Log? This action cannot be undone.",
                "Confirm Clear Log",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    // We've already ensured logFilePath is set in the constructor.
                    // Now, just clear the file and rewrite the header.
                    File.WriteAllText(logFilePath, "Timestamp,TestCaseID,Keyword,Execution_Flag\n");
                    MessageBox.Show("Execution Log cleared successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (IOException ex)
                {
                    MessageBox.Show($"Error clearing Execution Log: {ex.Message}\nEnsure the file is not open in another program.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (UnauthorizedAccessException ex)
                {
                    MessageBox.Show($"Permission denied to clear Execution Log: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

    }
}