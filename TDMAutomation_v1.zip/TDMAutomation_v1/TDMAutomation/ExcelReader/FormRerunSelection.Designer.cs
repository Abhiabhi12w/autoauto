﻿namespace TDMAutomation
{
    partial class FormRerunSelection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvRerunSteps = new System.Windows.Forms.DataGridView();
            this.btnRunSelected = new System.Windows.Forms.Button();
            this.btnSkipSelected = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button(); // This is the 'Cancel' button
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectAll = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRerunSteps)).BeginInit();
            this.SuspendLayout();
            //
            // dgvRerunSteps
            //
            this.dgvRerunSteps.AllowUserToAddRows = false;
            this.dgvRerunSteps.AllowUserToDeleteRows = false;
            this.dgvRerunSteps.AllowUserToResizeRows = false;
            this.dgvRerunSteps.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRerunSteps.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvRerunSteps.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvRerunSteps.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvRerunSteps.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRerunSteps.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvRerunSteps.Location = new System.Drawing.Point(10, 35);
            this.dgvRerunSteps.Name = "dgvRerunSteps";
            this.dgvRerunSteps.RowHeadersVisible = false;
            this.dgvRerunSteps.RowHeadersWidth = 51;
            this.dgvRerunSteps.RowTemplate.Height = 24;
            this.dgvRerunSteps.Size = new System.Drawing.Size(780, 360);
            this.dgvRerunSteps.TabIndex = 0;
            //
            // btnRunSelected
            //
            this.btnRunSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRunSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRunSelected.Location = new System.Drawing.Point(688, 404);
            this.btnRunSelected.Name = "btnRunSelected";
            this.btnRunSelected.Size = new System.Drawing.Size(100, 34);
            this.btnRunSelected.TabIndex = 1;
            this.btnRunSelected.Text = "Run Selected";
            this.btnRunSelected.UseVisualStyleBackColor = true;
            this.btnRunSelected.Click += new System.EventHandler(this.btnRunSelected_Click);
            //
            // btnSkipSelected
            //
            this.btnSkipSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSkipSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSkipSelected.Location = new System.Drawing.Point(578, 404);
            this.btnSkipSelected.Name = "btnSkipSelected";
            this.btnSkipSelected.Size = new System.Drawing.Size(100, 34);
            this.btnSkipSelected.TabIndex = 2;
            this.btnSkipSelected.Text = "Skip All"; // This button unchecks all selected steps
            this.btnSkipSelected.UseVisualStyleBackColor = true;
            this.btnSkipSelected.Click += new System.EventHandler(this.btnSkipSelected_Click);
            //
            // btnCancel
            //
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(12, 404);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 34);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel"; // This button closes the form with DialogResult.Cancel
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            //
            // label1
            //
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Select steps to rerun (uncheck to skip):";
            //
            // btnSelectAll
            //
            this.btnSelectAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectAll.Location = new System.Drawing.Point(468, 404);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(100, 34);
            this.btnSelectAll.TabIndex = 5;
            this.btnSelectAll.Text = "Select All"; // This button checks all selected steps
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            //
            // FormRerunSelection
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSelectAll);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel); // Ensure this line is present
            this.Controls.Add(this.btnSkipSelected);
            this.Controls.Add(this.btnRunSelected);
            this.Controls.Add(this.dgvRerunSteps);
            this.MinimizeBox = false;
            this.Name = "FormRerunSelection";
            this.ShowInTaskbar = false;
            this.Text = "Review Steps to Rerun";
            ((System.ComponentModel.ISupportInitialize)(this.dgvRerunSteps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvRerunSteps;
        private System.Windows.Forms.Button btnRunSelected;
        private System.Windows.Forms.Button btnSkipSelected;
        private System.Windows.Forms.Button btnCancel; // This declaration is present
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSelectAll;
    }
}