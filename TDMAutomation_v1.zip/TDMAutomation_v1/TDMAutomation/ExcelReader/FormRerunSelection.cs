﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Drawing; // Ensure this using statement is present

namespace TDMAutomation // Ensure this namespace matches your project's main namespace
{
    public partial class FormRerunSelection : Form
    {
        public DataTable RerunStepsDataTable { get; set; }

        public FormRerunSelection(DataTable stepsToReview)
        {
            InitializeComponent();

            RerunStepsDataTable = stepsToReview;

            // Ensure the "RerunSelected" column exists and is the first column
            if (!RerunStepsDataTable.Columns.Contains("RerunSelected"))
            {
                DataColumn rerunSelectionColumn = new DataColumn("RerunSelected", typeof(bool));
                RerunStepsDataTable.Columns.Add(rerunSelectionColumn);
                rerunSelectionColumn.SetOrdinal(0); // Make it the first column
            }

            // Default all steps to be selected for rerun
            foreach (DataRow row in RerunStepsDataTable.Rows)
            {
                row["RerunSelected"] = true;
            }

            dgvRerunSteps.DataSource = RerunStepsDataTable;

            // Customize the "RerunSelected" column to be a checkbox column
            if (dgvRerunSteps.Columns.Contains("RerunSelected"))
            {
                DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
                checkBoxColumn.HeaderText = "Rerun?";
                checkBoxColumn.Name = "RerunSelected";
                checkBoxColumn.DataPropertyName = "RerunSelected";
                checkBoxColumn.TrueValue = true;
                checkBoxColumn.FalseValue = false;
                checkBoxColumn.ThreeState = false;

                int columnIndex = dgvRerunSteps.Columns["RerunSelected"].Index;
                dgvRerunSteps.Columns.Remove("RerunSelected");
                dgvRerunSteps.Columns.Insert(columnIndex, checkBoxColumn);

                // Center the header text for the "Rerun?" checkbox column
                dgvRerunSteps.Columns["RerunSelected"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

            // Prevent users from adding or deleting rows directly from the grid
            dgvRerunSteps.AllowUserToAddRows = false;
            dgvRerunSteps.ReadOnly = false; // Allow editing of the checkbox column

            // Make all other columns read-only
            foreach (DataGridViewColumn col in dgvRerunSteps.Columns)
            {
                if (col.Name != "RerunSelected")
                {
                    col.ReadOnly = true;
                }
            }

            // Set column auto-sizing mode to fill the available width
            dgvRerunSteps.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Override the auto-sizing for the checkbox column to prevent it from becoming too wide
            // It will auto-size based on its content (the checkbox and header text)
            if (dgvRerunSteps.Columns.Contains("RerunSelected"))
            {
                dgvRerunSteps.Columns["RerunSelected"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            }

            // Optional: Advanced styling (uncomment if you want to apply these)
            // dgvRerunSteps.EnableHeadersVisualStyles = false; // Must be false for custom header styles
            // dgvRerunSteps.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(0, 122, 204);
            // dgvRerunSteps.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            // dgvRerunSteps.ColumnHeadersDefaultCellStyle.Font = new Font(dgvRerunSteps.Font, FontStyle.Bold);
            // dgvRerunSteps.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            // dgvRerunSteps.RowsDefaultCellStyle.BackColor = Color.White;
            // dgvRerunSteps.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue;
            // dgvRerunSteps.DefaultCellStyle.Padding = new Padding(3);
        }

        private void btnRunSelected_Click(object sender, EventArgs e)
        {
            dgvRerunSteps.EndEdit(); // Commit any pending checkbox edits
            this.DialogResult = DialogResult.OK; // Indicate that OK was clicked
            this.Close();
        }

        private void btnSkipSelected_Click(object sender, EventArgs e)
        {
            dgvRerunSteps.EndEdit(); // Commit any pending checkbox edits
            // Set all "RerunSelected" checkboxes to false
            foreach (DataRow row in RerunStepsDataTable.Rows)
            {
                row["RerunSelected"] = false;
            }
            dgvRerunSteps.Invalidate(); // Force the DataGridView to repaint and show changes immediately
        }

        // Event handler for the "Cancel" button (closes the form)
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; // Indicate that Cancel was clicked
            this.Close();
        }

        // Event handler for the "Select All" button (checks all checkboxes)
        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            dgvRerunSteps.EndEdit(); // Commit any pending checkbox edits
            // Set all "RerunSelected" checkboxes to true
            foreach (DataRow row in RerunStepsDataTable.Rows)
            {
                row["RerunSelected"] = true;
            }
            dgvRerunSteps.Invalidate(); // Force the DataGridView to repaint and show changes immediately
        }
    }
}